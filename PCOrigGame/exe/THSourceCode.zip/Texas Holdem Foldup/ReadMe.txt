This is a working simulator of Texas Hold'em Fold Up. It will work on a Windows PC.

To use:
1. Copy this directory to an empty directory on your hard-drive.
2. Navigate to this previously empty directory.
3. Navigate to the emu_44 subdirectory.
4. Run the program emu044.exe by double-clicking on it.

Note:
You must add some money in order to play the game. This is most easily done by
pressing on the green button next to $1 on the right-hand side of the screen.